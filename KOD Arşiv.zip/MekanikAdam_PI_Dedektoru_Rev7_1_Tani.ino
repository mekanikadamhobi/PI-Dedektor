/*
  MekanikAdam AYAKKABI İÇİ PI METAL DEDEKTÖRÜ
  Yazılım sürümü : 7.1.0 (Rev7.0 + watchdog + tanı ekranı + kapı taraması)
  Hedef kart      : STM32F401CCU6 Black Pill
  Arduino çekirdeği: STM32 MCU based boards 3.0.0
  Ekran           : SSD1306 128x64 I2C
  Ekran kütüphanesi: U8g2 (UTF-8 ve Türkçe karakter desteği)

  BU YAZILIMDA BULUNANLAR
  - Açılışta büyük/küçük harfe duyarlı "MekanikAdam" logosu.
  - Açılışta otomatik metalsiz ortam/toprak kalibrasyonu.
  - Değersiz olasılığında kalın, kararsız hedefte orta,
    değerli olasılığında ince ses.
  - PT2257 ile 0...10 arası dijital ses seviyesi.
  - TX kapalıyken 300/650/1250 Hz bobinsiz ses testi.
  - Türkçe OLED menüsü ve Türkçe karakterler.
  - Ayakkabı, 30 cm PI, Özel 1 ve Özel 2 için ayrı hafıza.
  - 22/24 ayar altın, 14 ayar altın, 925 gümüş, folyo,
    açma halkası, bakır/pirinç ve demir için öğretme profilleri.
  - Her hedef testinde 20 ölçüm ve en az 18/20 kabul kuralı.
  - Metalsiz testte en çok 1/20 yanlış alarm kabul kuralı.
  - 1 TL referans parasıyla 2...50 cm arasında, sinyalin güvenilir
    kaldığı son noktaya kadar derinlik kalibrasyon yardımcısı.
  - Açılışta yeniden yapılan toprak ayarı; hedef/bobin/derinlik
    profilleri ise CRC denetimli iki kayıt yuvasında saklanır.
  - Batarya gerilimi izleme ve düşük batarya koruması.

  REV7.1 EKLERİ (Rev7.0 ölçüm ve sınıflandırma mantığı değişmedi)
  - Donanım watchdog (IWDG): yazılım kilitlenirse ~1 s içinde reset, TX kapanır.
  - Menü: TANI EKRANI (ham kapı değerleri, gürültü, ray sayısı, fark).
  - Menü: KAPI TARAMASI (osiloskopsuz sönüm eğrisi, grafik + tablo).
  - Tüm delay() çağrıları watchdog'u besleyen safeDelay() oldu.

  ÖNEMLİ SINIR
  Derinlik, kalibrasyonda kullanılan 1 TL büyüklüğündeki hedefe göre
  yaklaşık değerdir. Hedefin boyutu, metali, açısı ve toprak yapısı
  gerçek derinliği değiştirir. Metal sınıfı kesin kimlik veya kimyasal
  analiz değildir; öğretme örneklerine göre olasılıktır. Bobin değişimi
  yalnız cihaz kapalıyken yapılmalıdır. Yeni bobin, bu devreye elektriksel
  olarak uygun PI mono bobin olmalıdır. Osiloskop/LCR olmadan darbe süresini
  veya örnekleme kapılarını değiştirmeyin.
*/

#include <Arduino.h>
#include <Wire.h>
#include <U8g2lib.h>
#include <EEPROM.h>
#include <math.h>
#include <string.h>

// STM32duino'nun tamponlu EEPROM işlevleri, yüzlerce ayrı Flash silmesi
// yerine tüm ayarları RAM'de hazırlayıp yalnız bir Flash yazımı yapar.
extern "C" {
  void eeprom_buffer_fill(void);
  void eeprom_buffer_flush(void);
  void eeprom_buffered_write_byte(uint32_t position, uint8_t value);
}

// -------------------------------------------------------------------------
// 1. SON BAĞLANTI BELGESİYLE AYNI PINLER
// -------------------------------------------------------------------------
static const uint32_t PIN_TX       = PA_1;  // TC4420 pin 2 girişi
static const uint32_t PIN_BLANK    = PA_2;  // 74HC4066 pin 13 kontrolü
static const uint32_t PIN_AUDIO    = PA_8;  // PT2257 üzerinden LM386'ya ton
static const uint32_t PIN_BTN_MENU = PB12;  // Butonların diğer bacağı GND
static const uint32_t PIN_BTN_UP   = PB13;
static const uint32_t PIN_BTN_DOWN = PB14;
static const uint32_t PIN_BTN_OK   = PB15;

static const uint32_t I2C_SCL_PIN  = PB6;   // OLED SCL + PT2257 SCL
static const uint32_t I2C_SDA_PIN  = PB7;   // OLED SDA + PT2257 SDA

// PA0 = ADC1_IN0 alıcı sinyali, PA4 = ADC1_IN4 batarya bölücüsü.
static const uint8_t ADC_CH_SIGNAL  = 0;
static const uint8_t ADC_CH_BATTERY = 4;

// -------------------------------------------------------------------------
// 2. PI DARBE VE ÖRNEKLEME AYARLARI
// -------------------------------------------------------------------------
// Osiloskop/LCR olmadan güvenli ilk çalışma değerleridir.
// Cihaz gerçek bobinle test edilmeden bu sayıları değiştirme.
static const uint16_t PULSE_US        = 80;
static const uint16_t BLANK_RELEASE_US = 28;
static const uint16_t GATE_US[4]      = {40, 55, 80, 120};
static const uint16_t PULSE_PERIOD_US = 10000;  // 100 darbe/saniye
static const uint8_t  PULSES_PER_BLOCK = 8;

static const float ADC_VREF = 3.300f;
static const float BAT_DIVIDER = 127.0f / 27.0f;  // 100 kΩ üst, 27 kΩ alt
static const float NORMALIZATION_VOLTAGE = 12.0f;
static const float LOW_BATTERY_CUTOFF_V = 9.50f;
// Flash silme/yazma sırasında ek gerilim payı bırakılır. 9,50...9,99 V
// aralığında dedektör çalışabilir, fakat ayarlar hafızaya yazılmaz.
static const float FLASH_SAVE_MIN_V = 10.00f;

// Derinlik yardımcısında kullanılacak sabit mesafeler.
static const uint8_t DEPTH_POINT_COUNT = 10;
static const uint8_t DEPTH_CM[DEPTH_POINT_COUNT] = {
  2, 5, 10, 15, 20, 25, 30, 35, 40, 50
};

static const uint8_t COIL_PROFILE_COUNT = 4;
static const uint8_t TARGET_PROFILE_COUNT = 7;
static const uint8_t FEATURE_COUNT = 5;
static const uint8_t TEACH_MEASUREMENT_COUNT = 20;
static const uint8_t TEACH_TARGET_MIN_HITS = 18;
static const uint8_t TEACH_BLANK_MAX_FALSE = 1;
static const uint16_t PROFILE_MIN_SAMPLES = 18;

// -------------------------------------------------------------------------
// 3. OLED VE PT2257
// -------------------------------------------------------------------------
U8G2_SSD1306_128X64_NONAME_F_HW_I2C display(U8G2_R0, U8X8_PIN_NONE);

static const uint8_t PT2257_ADDRESS = 0x44;  // Wire için 7 bit adres
static const uint8_t PT2257_BOTH_1DB  = 0xD0;
static const uint8_t PT2257_BOTH_10DB = 0xE0;
static const uint8_t PT2257_MUTE_BASE = 0x78;

// Ses seviyesi 0 tamamen sessizdir. 10 en yüksek seviyedir.
// Sayılar PT2257'nin uygulayacağı zayıflatma miktarıdır.
static const uint8_t VOLUME_ATTENUATION_DB[11] = {
  79, 50, 40, 32, 26, 20, 15, 11, 7, 3, 0
};

bool pt2257Present = false;

// -------------------------------------------------------------------------
// 4. AYARLAR VE ÖLÇÜM VERİLERİ
// -------------------------------------------------------------------------
enum TargetClass : uint8_t {
  CLASS_NONE = 0,
  CLASS_TRASH,
  CLASS_UNCERTAIN,
  CLASS_VALUABLE
};

enum TeachTarget : uint8_t {
  TARGET_GOLD_22_24 = 0,
  TARGET_GOLD_14,
  TARGET_SILVER_925,
  TARGET_FOIL,
  TARGET_PULL_TAB,
  TARGET_COPPER_BRASS,
  TARGET_IRON,
  TARGET_BLANK
};

enum TestEnvironment : uint8_t {
  ENV_AIR = 0,
  ENV_DRY_GROUND,
  ENV_WET_GROUND,
  ENV_COUNT
};

enum TestOrientation : uint8_t {
  ORIENT_HORIZONTAL = 0,
  ORIENT_VERTICAL,
  ORIENT_COUNT
};

struct FeatureProfile {
  uint16_t count;
  uint16_t sessions;
  uint16_t distanceMask;
  uint8_t orientationMask;
  uint8_t environmentMask;
  float mean[FEATURE_COUNT];
  float m2[FEATURE_COUNT];
};

struct CoilProfile {
  float trashRatio;
  float valuableRatio;
  uint8_t depthPoints;
  uint8_t reserved[3];
  float depthStrength[DEPTH_POINT_COUNT];
  FeatureProfile targets[TARGET_PROFILE_COUNT];
  uint16_t blankSessions;
  uint8_t lastBlankFalse;
  uint8_t blankEnvironmentMask;
};

struct Settings {
  uint32_t magic;
  uint16_t version;
  uint16_t bytes;
  uint32_t sequence;
  uint8_t sensitivity;       // 1...10
  uint8_t audioLength;       // 1...8
  uint8_t autoTrack;         // 0/1
  uint8_t volumeLevel;       // 0...10
  uint8_t activeCoil;        // 0...3
  uint8_t reserved[3];
  CoilProfile coils[COIL_PROFILE_COUNT];
  uint16_t crc;
  uint16_t footer;
};

static const uint32_t SETTINGS_MAGIC = 0x50493630UL;  // "PI60"
static const uint16_t SETTINGS_VERSION = 0x0600;
static const uint16_t SETTINGS_FOOTER = 0x6A3C;
static const uint16_t SETTINGS_SLOT_SIZE = 2048;
static_assert(sizeof(Settings) <= SETTINGS_SLOT_SIZE,
              "Ayar yapısı bir EEPROM yuvasına sığmıyor");
#if defined(E2END)
static_assert(SETTINGS_SLOT_SIZE * 2UL <= E2END + 1UL,
              "EEPROM alanı iki ayar yuvası için yetersiz");
#endif

Settings settings;
int8_t loadedSettingsSlot = -1;
bool settingsDirty = false;

struct Measurement {
  float gate[4];
  float delta[4];
  float magnitude;
  float normalizedMagnitude;
  float ratio;
  float classScore;
  float confidence;
  float feature[FEATURE_COUNT];
  float estimatedDepthCm;
  int8_t bestProfile;
  TargetClass targetClass;
};

// Bu iki tür ilk işlev tanımından önce bulunmalıdır. Arduino'nun .ino
// ön-işlemcisi işlev bildirimlerini otomatik üretirken, daha aşağıda
// tanımlanan özel türleri henüz tanımadığı için derleme hatası oluşur.
enum WizardAction : uint8_t {
  WIZARD_OK,
  WIZARD_CANCEL
};

struct RunningStats {
  uint16_t count;
  float mean[FEATURE_COUNT];
  float m2[FEATURE_COUNT];
};

// Rev7.1: tanı ve tarama modları için sabitler ve yapılar.
// Arduino otomatik prototip üretir; bu yüzden yapı tanımları
// fonksiyonlardan ÖNCE, dosyanın başında olmalıdır.
static const uint8_t SCAN_POINTS = 32;
static const uint8_t SCAN_STEP_US = 4;
static const uint8_t SCAN_PULSES = 16;
static const uint8_t SCAN_PAGE_COUNT = 10;
static const uint16_t ADC_RAIL_LOW = 16;
static const uint16_t ADC_RAIL_HIGH = 4079;
static const uint16_t SCAN_START_PRODUCTION_US = 30;
static const uint16_t SCAN_START_EARLY_US = 10;
static const uint16_t SCAN_BLANK_EARLY_US = 8;

struct ScanResult {
  uint16_t startUs;
  uint16_t blankUs;
  uint16_t rails;
  float mean[SCAN_POINTS];
  uint16_t minValue[SCAN_POINTS];
  uint16_t maxValue[SCAN_POINTS];
};

struct LiveStats {
  float mean[4];
  uint16_t pp[4];
  uint16_t rails;
};


float baseline[4] = {2048, 2048, 2048, 2048};
float filteredGate[4] = {2048, 2048, 2048, 2048};
float runtimeNoise = 0.0f;
bool filterReady = false;
bool baselineReady = false;
bool menuOpen = false;
bool editMode = false;
bool lowBatteryLatched = false;
bool timingFaultLatched = false;
bool adcFaultLatched = false;
uint8_t menuIndex = 0;
float batteryVoltage = 0.0f;
uint32_t lastBatteryMs = 0;
uint32_t lastDisplayMs = 0;
Measurement lastMeasurement;

static const uint8_t CLASS_HISTORY_COUNT = 5;
TargetClass classHistory[CLASS_HISTORY_COUNT] = {
  CLASS_NONE, CLASS_NONE, CLASS_NONE, CLASS_NONE, CLASS_NONE
};
uint8_t classHistoryIndex = 0;
uint8_t classHistoryFilled = 0;

// Aşağıdaki üç işlev daha ileride tanımlıdır; Flash kaydı sırasında bobin
// vuruşunu ve sesi güvenle durdurmak için burada önceden bildirilir.
static inline void txLow();
static inline void blankHigh();
static void audioOff();
static float readBatteryVoltage();

// -------------------------------------------------------------------------
// 4B. DONANIM WATCHDOG (IWDG) - Rev7.1
// -------------------------------------------------------------------------
// Yazılım kilitlenirse STM32 yaklaşık 1 saniye içinde kendini resetler.
// Reset sırasında PA1 boşa düşer; TC4420 girişindeki 100 kΩ pull-down
// IRF740'ı kapatır. Watchdog bir kez başlatılınca yazılımla kapatılamaz.
// Normal zaman aşımı yaklaşık 1,0 s'dir (LSI toleransı yüzünden 0,7...1,9 s).
// Flash silme 1-2 s sürebildiği için kayıt sırasında süre geçici uzatılır.
static void wdtWriteConfig(uint32_t prescaler, uint32_t reload) {
  IWDG->KR = 0x5555;
  IWDG->PR = prescaler;
  IWDG->RLR = reload;
  uint32_t guard = 3000000UL;
  while (IWDG->SR != 0 && --guard) {
    __NOP();
  }
  IWDG->KR = 0xAAAA;
}

static inline void wdtFeed() {
  IWDG->KR = 0xAAAA;
}

static void wdtNormalTimeout() {
  wdtWriteConfig(3, 1000);  // LSI/32 -> yaklaşık 1 s
}

static void wdtLongTimeout() {
  wdtWriteConfig(6, 4095);  // LSI/256 -> yaklaşık 33 s (yalnız Flash yazımı)
}

static void wdtStart() {
  IWDG->KR = 0xCCCC;
  wdtNormalTimeout();
}

// delay() yerine kullanılır: bekleme boyunca watchdog'u besler.
static void safeDelay(uint32_t ms) {
  while (ms > 0) {
    uint32_t chunk = ms > 10 ? 10 : ms;
    wdtFeed();
    delay(chunk);
    ms -= chunk;
  }
}

// -------------------------------------------------------------------------
// 5. EEPROM KONTROLÜ
// -------------------------------------------------------------------------
static uint16_t crc16Ccitt(const uint8_t *data, size_t length) {
  uint16_t crc = 0xFFFF;
  while (length--) {
    crc ^= (uint16_t)(*data++) << 8;
    for (uint8_t i = 0; i < 8; i++) {
      crc = (crc & 0x8000) ? (uint16_t)((crc << 1) ^ 0x1021)
                           : (uint16_t)(crc << 1);
    }
  }
  return crc;
}

static CoilProfile &activeCoilProfile() {
  return settings.coils[settings.activeCoil];
}

static const CoilProfile &activeCoilProfileConst() {
  return settings.coils[settings.activeCoil];
}

static void setDefaultSettings() {
  memset(&settings, 0, sizeof(settings));
  settings.magic = SETTINGS_MAGIC;
  settings.version = SETTINGS_VERSION;
  settings.bytes = sizeof(Settings);
  settings.sequence = 0;
  settings.sensitivity = 6;
  settings.audioLength = 4;
  settings.autoTrack = 1;
  settings.volumeLevel = 5;
  settings.activeCoil = 0;
  for (uint8_t coil = 0; coil < COIL_PROFILE_COUNT; coil++) {
    settings.coils[coil].trashRatio = 0.18f;
    settings.coils[coil].valuableRatio = 0.45f;
  }
  settings.crc = 0;
  settings.footer = SETTINGS_FOOTER;
  loadedSettingsSlot = -1;
  settingsDirty = true;
}

static bool featureProfileValid(const FeatureProfile &profile) {
  if ((profile.distanceMask & ~((1U << DEPTH_POINT_COUNT) - 1U)) != 0) {
    return false;
  }
  if ((profile.orientationMask & ~0x03U) != 0 ||
      (profile.environmentMask & ~0x07U) != 0) {
    return false;
  }
  if (profile.count == 0 && profile.sessions != 0) return false;
  if (profile.count > 0 && profile.sessions == 0) return false;
  if (profile.count > 0 &&
      (profile.distanceMask == 0 || profile.orientationMask == 0 ||
       profile.environmentMask == 0)) {
    return false;
  }
  for (uint8_t f = 0; f < FEATURE_COUNT; f++) {
    if (!isfinite(profile.mean[f]) || !isfinite(profile.m2[f]) ||
        profile.m2[f] < -0.0001f) {
      return false;
    }
  }
  return true;
}

static bool coilProfileValid(const CoilProfile &profile) {
  if (!isfinite(profile.trashRatio) || !isfinite(profile.valuableRatio) ||
      fabsf(profile.valuableRatio - profile.trashRatio) < 0.03f) {
    return false;
  }
  if (profile.depthPoints > DEPTH_POINT_COUNT) return false;
  for (uint8_t i = 0; i < profile.depthPoints; i++) {
    if (!isfinite(profile.depthStrength[i]) ||
        profile.depthStrength[i] <= 0.0f) {
      return false;
    }
    if (i > 0 && profile.depthStrength[i] >= profile.depthStrength[i - 1]) {
      return false;
    }
  }
  for (uint8_t target = 0; target < TARGET_PROFILE_COUNT; target++) {
    if (!featureProfileValid(profile.targets[target])) return false;
  }
  if ((profile.blankEnvironmentMask & ~0x07U) != 0) return false;
  if (profile.blankSessions > 0 &&
      (profile.lastBlankFalse > TEACH_MEASUREMENT_COUNT ||
       profile.blankEnvironmentMask == 0)) {
    return false;
  }
  return true;
}

static bool settingsRecordValid(const Settings &candidate) {
  if (candidate.magic != SETTINGS_MAGIC ||
      candidate.version != SETTINGS_VERSION ||
      candidate.bytes != sizeof(Settings) ||
      candidate.footer != SETTINGS_FOOTER ||
      candidate.sensitivity < 1 || candidate.sensitivity > 10 ||
      candidate.audioLength < 1 || candidate.audioLength > 8 ||
      candidate.volumeLevel > 10 || candidate.autoTrack > 1 ||
      candidate.activeCoil >= COIL_PROFILE_COUNT) {
    return false;
  }

  for (uint8_t coil = 0; coil < COIL_PROFILE_COUNT; coil++) {
    if (!coilProfileValid(candidate.coils[coil])) return false;
  }

  Settings checked = candidate;
  uint16_t stored = checked.crc;
  checked.crc = 0;
  return stored == crc16Ccitt((const uint8_t *)&checked, sizeof(checked));
}

static bool sequenceIsNewer(uint32_t first, uint32_t second) {
  return (int32_t)(first - second) > 0;
}

static bool settingsStorageAvailable() {
  return EEPROM.length() >= SETTINGS_SLOT_SIZE * 2U;
}

static void loadSettings() {
  if (!settingsStorageAvailable()) {
    setDefaultSettings();
    return;
  }
  Settings slot0;
  Settings slot1;
  EEPROM.get(0, slot0);
  EEPROM.get(SETTINGS_SLOT_SIZE, slot1);
  bool valid0 = settingsRecordValid(slot0);
  bool valid1 = settingsRecordValid(slot1);

  if (!valid0 && !valid1) {
    setDefaultSettings();
    return;
  }

  if (valid1 && (!valid0 || sequenceIsNewer(slot1.sequence, slot0.sequence))) {
    settings = slot1;
    loadedSettingsSlot = 1;
  } else {
    settings = slot0;
    loadedSettingsSlot = 0;
  }
  settingsDirty = false;
}

static bool saveSettings() {
  if (!settingsStorageAvailable()) {
    settingsDirty = true;
    return false;
  }

  // Flash işlemi tam sektör silip yazabilir. Her kayıttan hemen önce gerçek
  // bataryayı yeniden ölç; zayıf veya geçersiz beslemede yazmayı başlatma.
  batteryVoltage = readBatteryVoltage();
  if (adcFaultLatched || !isfinite(batteryVoltage) ||
      batteryVoltage < FLASH_SAVE_MIN_V) {
    if (isfinite(batteryVoltage) &&
        batteryVoltage < LOW_BATTERY_CUTOFF_V) {
      lowBatteryLatched = true;
    }
    settingsDirty = true;
    return false;
  }
  settings.magic = SETTINGS_MAGIC;
  settings.version = SETTINGS_VERSION;
  settings.bytes = sizeof(Settings);
  settings.footer = SETTINGS_FOOTER;
  settings.sequence++;
  settings.crc = 0;
  settings.crc = crc16Ccitt((const uint8_t *)&settings, sizeof(settings));

  int8_t destinationSlot = (loadedSettingsSlot == 0) ? 1 : 0;
  int destinationAddress = destinationSlot * SETTINGS_SLOT_SIZE;

  // EEPROM.put() bu STM32 ailesinde değişen her bayt için tüm Flash sektörünü
  // yeniden yazabilir. Tamponlu yöntemle tek kayıt işlemi yapılır.
  eeprom_buffer_fill();
  const uint8_t *source = (const uint8_t *)&settings;
  for (size_t i = 0; i < sizeof(settings); i++) {
    eeprom_buffered_write_byte((uint32_t)destinationAddress + i, source[i]);
  }
  txLow();
  blankHigh();
  audioOff();
  wdtLongTimeout();
  eeprom_buffer_flush();
  wdtNormalTimeout();

  Settings verification;
  EEPROM.get(destinationAddress, verification);
  if (!settingsRecordValid(verification) ||
      verification.sequence != settings.sequence) {
    settingsDirty = true;
    return false;
  }

  settings = verification;
  loadedSettingsSlot = destinationSlot;
  settingsDirty = false;
  return true;
}

// -------------------------------------------------------------------------
// 6. HASSAS ZAMANLAMA VE DOĞRUDAN ADC
// -------------------------------------------------------------------------
static inline uint32_t usToCycles(uint32_t us) {
  return (SystemCoreClock / 1000000UL) * us;
}

static bool waitUntilCycle(uint32_t target) {
  uint32_t guard = 200000UL;
  while ((int32_t)(DWT->CYCCNT - target) < 0) {
    __NOP();
    if (--guard == 0) return false;
  }
  return true;
}

static bool enableCycleCounter() {
  CoreDebug->DEMCR |= CoreDebug_DEMCR_TRCENA_Msk;
  DWT->CYCCNT = 0;
  DWT->CTRL |= DWT_CTRL_CYCCNTENA_Msk;
  uint32_t first = DWT->CYCCNT;
  for (volatile uint32_t i = 0; i < 64; i++) __NOP();
  return DWT->CYCCNT != first;
}

// PA1 ve PA2 aynı GPIOA portundadır. BSRR kullanımı darbe kenarlarını
// digitalWrite'a göre daha kesin zamanda oluşturur.
static inline void txHigh()    { GPIOA->BSRR = (1UL << 1); }
static inline void txLow()     { GPIOA->BSRR = (1UL << (1 + 16)); }
static inline void blankHigh() { GPIOA->BSRR = (1UL << 2); }
static inline void blankLow()  { GPIOA->BSRR = (1UL << (2 + 16)); }

// ADC1: 12 bit, yazılımla tetiklenen tek dönüşüm.
// APB2 84 MHz olduğunda ADC saati /4 ile yaklaşık 21 MHz olur.
static void adcInitDirect() {
  RCC->AHB1ENR |= RCC_AHB1ENR_GPIOAEN;
  RCC->APB2ENR |= RCC_APB2ENR_ADC1EN;

  GPIOA->MODER |= (3UL << (0 * 2));
  GPIOA->MODER |= (3UL << (4 * 2));
  GPIOA->PUPDR &= ~((3UL << (0 * 2)) | (3UL << (4 * 2)));

  ADC->CCR = (ADC->CCR & ~ADC_CCR_ADCPRE) | ADC_CCR_ADCPRE_0;
  ADC1->CR1 = 0;
  ADC1->CR2 = ADC_CR2_ADON;
  ADC1->SQR1 = 0;
  delayMicroseconds(10);
}

// sampleCode: 0=3, 1=15, 2=28, 3=56, 4=84, 5=112, 6=144,
// 7=480 ADC örnekleme çevrimi.
static inline uint16_t adcReadDirect(uint8_t channel, uint8_t sampleCode) {
  uint32_t shift = (uint32_t)channel * 3UL;
  ADC1->SMPR2 = (ADC1->SMPR2 & ~(7UL << shift)) |
                (((uint32_t)sampleCode & 7UL) << shift);
  ADC1->SQR3 = channel;
  ADC1->SR = 0;
  ADC1->CR2 |= ADC_CR2_SWSTART;
  uint32_t guard = 100000UL;
  while ((ADC1->SR & ADC_SR_EOC) == 0) {
    __NOP();
    if (--guard == 0) {
      adcFaultLatched = true;
      return 0;
    }
  }
  return (uint16_t)ADC1->DR;
}

// -------------------------------------------------------------------------
// 7. BUTONLAR VE SES
// -------------------------------------------------------------------------
static bool buttonPressed(uint32_t pin) {
  static uint32_t lastMs[4] = {0, 0, 0, 0};
  uint8_t index = 0;
  if (pin == PIN_BTN_UP) index = 1;
  else if (pin == PIN_BTN_DOWN) index = 2;
  else if (pin == PIN_BTN_OK) index = 3;

  if (digitalRead(pin) == LOW && (millis() - lastMs[index]) > 220) {
    safeDelay(18);
    if (digitalRead(pin) == LOW) {
      lastMs[index] = millis();
      return true;
    }
  }
  return false;
}

static void waitButtonRelease(uint32_t pin) {
  while (digitalRead(pin) == LOW) safeDelay(5);
}

static void audioOff() {
  noTone(PIN_AUDIO);
  digitalWrite(PIN_AUDIO, LOW);
}

static void playClassTone(TargetClass cls) {
  if (cls == CLASS_NONE || settings.volumeLevel == 0) return;

  uint16_t frequency = 650;
  if (cls == CLASS_TRASH) frequency = 300;       // Kalın ses
  if (cls == CLASS_VALUABLE) frequency = 1250;  // İnce ses

  uint16_t duration = 18 + 7 * settings.audioLength;
  tone(PIN_AUDIO, frequency);
  safeDelay(duration);
  audioOff();
  safeDelay(6);
}

// -------------------------------------------------------------------------
// 8. PT2257 DİJİTAL SES KONTROLÜ
// -------------------------------------------------------------------------
static bool pt2257Write2(uint8_t first, uint8_t second) {
  Wire.beginTransmission(PT2257_ADDRESS);
  Wire.write(first);
  Wire.write(second);
  return Wire.endTransmission() == 0;
}

static bool pt2257Mute(bool muteOn) {
  Wire.beginTransmission(PT2257_ADDRESS);
  Wire.write((uint8_t)(PT2257_MUTE_BASE | (muteOn ? 1 : 0)));
  return Wire.endTransmission() == 0;
}

static bool pt2257SetAttenuation(uint8_t attenuationDb) {
  if (attenuationDb > 79) attenuationDb = 79;
  uint8_t tens = attenuationDb / 10;
  uint8_t ones = attenuationDb % 10;
  return pt2257Write2((uint8_t)(PT2257_BOTH_10DB | tens),
                      (uint8_t)(PT2257_BOTH_1DB | ones));
}

static bool applyVolumeLevel() {
  uint8_t level = settings.volumeLevel;
  if (level > 10) level = 10;

  if (level == 0) {
    bool levelOk = pt2257SetAttenuation(79);
    bool muteOk = pt2257Mute(true);
    return levelOk && muteOk;
  }

  bool levelOk = pt2257SetAttenuation(VOLUME_ATTENUATION_DB[level]);
  bool muteOk = pt2257Mute(false);
  return levelOk && muteOk;
}

static bool initializePt2257() {
  // PT2257 güç verildikten sonra en az 200 ms beklenmesini ister.
  if (millis() < 220) safeDelay(220 - millis());

  // Önce en düşük ses, sonra mute kapalı ve kayıtlı seviye uygulanır.
  if (!pt2257SetAttenuation(79)) return false;
  if (!pt2257Mute(false)) return false;
  return applyVolumeLevel();
}

// -------------------------------------------------------------------------
// 9. PI ÖLÇÜMÜ
// -------------------------------------------------------------------------
static float detectionThreshold() {
  // Hassasiyet 1: yaklaşık 66 ADC sayımı, hassasiyet 10: 12 sayım.
  return 72.0f - 6.0f * (float)settings.sensitivity;
}

static float currentDetectionThreshold() {
  // Açılış toprak ayarında ölçülen gürültünün 4,5 katından daha küçük
  // eşik kullanılmaz. Böylece hassasiyet yükseltilse bile yalancı ötme azalır.
  float noiseThreshold = runtimeNoise * 4.5f;
  float userThreshold = detectionThreshold();
  return noiseThreshold > userThreshold ? noiseThreshold : userThreshold;
}

static float normalizeMagnitude(float magnitude) {
  float voltage = batteryVoltage;
  if (!isfinite(voltage) || voltage < 9.0f || voltage > 13.0f) {
    voltage = NORMALIZATION_VOLTAGE;
  }
  return magnitude * (NORMALIZATION_VOLTAGE / voltage);
}

static bool acquireOnePulse(uint16_t out[4]) {
  uint32_t frameStart = DWT->CYCCNT;

  blankHigh();
  txHigh();
  if (!waitUntilCycle(frameStart + usToCycles(PULSE_US))) {
    txLow();
    blankHigh();
    timingFaultLatched = true;
    return false;
  }
  txLow();
  uint32_t pulseOff = frameStart + usToCycles(PULSE_US);

  if (!waitUntilCycle(pulseOff + usToCycles(BLANK_RELEASE_US))) {
    txLow();
    blankHigh();
    timingFaultLatched = true;
    return false;
  }
  blankLow();

  for (uint8_t i = 0; i < 4; i++) {
    if (!waitUntilCycle(pulseOff + usToCycles(GATE_US[i]))) {
      txLow();
      blankHigh();
      timingFaultLatched = true;
      return false;
    }
    out[i] = adcReadDirect(ADC_CH_SIGNAL, 2);
    if (adcFaultLatched) {
      txLow();
      blankHigh();
      return false;
    }
  }

  blankHigh();
  return true;
}

static void readGateBlock(float out[4]) {
  uint32_t sum[4] = {0, 0, 0, 0};

  for (uint8_t pulse = 0; pulse < PULSES_PER_BLOCK; pulse++) {
    wdtFeed();
    uint32_t pulseStartUs = micros();
    uint16_t sample[4];

    noInterrupts();
    bool pulseOk = acquireOnePulse(sample);
    interrupts();

    if (!pulseOk) {
      txLow();
      blankHigh();
      for (uint8_t g = 0; g < 4; g++) out[g] = 0.0f;
      return;
    }

    for (uint8_t g = 0; g < 4; g++) sum[g] += sample[g];

    while ((uint32_t)(micros() - pulseStartUs) < PULSE_PERIOD_US) {
      delayMicroseconds(20);
    }
  }

  for (uint8_t g = 0; g < 4; g++) {
    out[g] = (float)sum[g] / (float)PULSES_PER_BLOCK;
  }
}

static float estimateDepthCm(float normalizedStrength) {
  const CoilProfile &coil = activeCoilProfileConst();
  if (coil.depthPoints < 3 || normalizedStrength <= 0.0f) return -1.0f;

  uint8_t count = coil.depthPoints;
  float firstStrength = coil.depthStrength[0];

  // İlk kalibrasyon noktasından daha güçlü sinyal: 0...2 cm aralığı.
  if (normalizedStrength >= firstStrength) {
    float depth = (float)DEPTH_CM[0] * firstStrength / normalizedStrength;
    if (depth < 0.0f) depth = 0.0f;
    if (depth > DEPTH_CM[0]) depth = DEPTH_CM[0];
    return depth;
  }

  // Sinyal-mesafe ilişkisi doğrusal olmadığı için logaritmik ara değer alınır.
  for (uint8_t i = 0; i + 1 < count; i++) {
    float nearStrength = coil.depthStrength[i];
    float farStrength = coil.depthStrength[i + 1];
    if (normalizedStrength <= nearStrength && normalizedStrength >= farStrength) {
      float numerator = logf(nearStrength) - logf(normalizedStrength);
      float denominator = logf(nearStrength) - logf(farStrength);
      float fraction = denominator > 0.0001f ? numerator / denominator : 0.0f;
      return (float)DEPTH_CM[i] +
             fraction * (float)(DEPTH_CM[i + 1] - DEPTH_CM[i]);
    }
  }

  // Son kayıtlı noktadan daha zayıf hedef kesin santimetre değildir.
  return (float)DEPTH_CM[count - 1] + 1.0f;
}

static bool targetProfileLearned(const FeatureProfile &profile) {
  return profile.count >= PROFILE_MIN_SAMPLES && profile.sessions > 0;
}

static float profileDistance(const FeatureProfile &profile,
                             const float feature[FEATURE_COUNT]) {
  if (!targetProfileLearned(profile)) return INFINITY;

  float sum = 0.0f;
  for (uint8_t f = 0; f < FEATURE_COUNT; f++) {
    float variance = 0.0f;
    if (profile.count > 1) {
      variance = profile.m2[f] / (float)(profile.count - 1);
    }
    // İlk dört özellik sönüm eğrisinin payları, beşinci özellik geç/erken
    // oranıdır. Alt sınır, tek bir öğretme oturumunun aşırı ezberlenmesini önler.
    float varianceFloor = (f < 4) ? 0.0025f : 0.0200f;
    if (!isfinite(variance) || variance < varianceFloor) {
      variance = varianceFloor;
    }
    float difference = feature[f] - profile.mean[f];
    sum += difference * difference / variance;
  }
  return sqrtf(sum / (float)FEATURE_COUNT);
}

static TargetClass legacyRatioClassification(Measurement &m) {
  const CoilProfile &coil = activeCoilProfileConst();
  float span = coil.valuableRatio - coil.trashRatio;
  if (fabsf(span) < 0.03f) span = (span < 0.0f) ? -0.03f : 0.03f;
  m.classScore = (m.ratio - coil.trashRatio) / span;
  m.bestProfile = -1;

  if (m.classScore < 0.35f) {
    m.confidence = 55.0f + fminf(35.0f, fabsf(m.classScore - 0.35f) * 50.0f);
    return CLASS_TRASH;
  }
  if (m.classScore > 0.65f) {
    m.confidence = 55.0f + fminf(35.0f, fabsf(m.classScore - 0.65f) * 50.0f);
    return CLASS_VALUABLE;
  }
  m.confidence = 35.0f;
  return CLASS_UNCERTAIN;
}

static TargetClass classifyFromLearnedProfiles(Measurement &m) {
  const CoilProfile &coil = activeCoilProfileConst();
  float bestValuable = INFINITY;
  float bestTrash = INFINITY;
  float bestNeutral = INFINITY;
  int8_t bestValuableIndex = -1;
  int8_t bestTrashIndex = -1;
  int8_t bestNeutralIndex = -1;

  for (uint8_t target = 0; target < TARGET_PROFILE_COUNT; target++) {
    float distance = profileDistance(coil.targets[target], m.feature);
    if (target <= TARGET_SILVER_925 && distance < bestValuable) {
      bestValuable = distance;
      bestValuableIndex = target;
    } else if ((target == TARGET_FOIL || target == TARGET_PULL_TAB ||
                target == TARGET_IRON) && distance < bestTrash) {
      bestTrash = distance;
      bestTrashIndex = target;
    } else if (target == TARGET_COPPER_BRASS && distance < bestNeutral) {
      bestNeutral = distance;
      bestNeutralIndex = target;
    }
  }

  // En az bir değerli ve bir değersiz örnek öğretilmeden gelişmiş ayrım
  // yapılmaz; güvenli eski oran yöntemi çalışmaya devam eder.
  if (!isfinite(bestValuable) || !isfinite(bestTrash)) {
    return legacyRatioClassification(m);
  }

  TargetClass candidate = CLASS_VALUABLE;
  float best = bestValuable;
  float competitor = bestTrash;
  int8_t bestIndex = bestValuableIndex;
  if (bestTrash < bestValuable) {
    candidate = CLASS_TRASH;
    best = bestTrash;
    competitor = bestValuable;
    bestIndex = bestTrashIndex;
  }

  // Bakır/pirinç profili iki ana grubun önüne geçerse kesin değerli/değersiz
  // denmez; kazılması gereken kararsız hedef olarak gösterilir.
  if (isfinite(bestNeutral) && bestNeutral < best * 0.92f) {
    m.bestProfile = bestNeutralIndex;
    m.classScore = 0.5f;
    m.confidence = fmaxf(30.0f, 70.0f - bestNeutral * 10.0f);
    return CLASS_UNCERTAIN;
  }

  if (isfinite(bestNeutral) && bestNeutral < competitor) {
    competitor = bestNeutral;
  }
  float separation = (competitor - best) / fmaxf(competitor, 0.10f);
  if (separation < 0.0f) separation = 0.0f;
  if (separation > 1.0f) separation = 1.0f;
  float fit = expf(-0.30f * best);
  m.confidence = 100.0f * (0.55f * fit + 0.45f * separation);
  if (m.confidence > 99.0f) m.confidence = 99.0f;
  if (m.confidence < 0.0f) m.confidence = 0.0f;
  m.bestProfile = bestIndex;
  m.classScore = candidate == CLASS_VALUABLE ? 1.0f : 0.0f;

  // Öğretilen hiçbir kümeye yeterince benzemeyen veya iki gruba çok yakın
  // hedef, yanlış kesinlik vermemek için KARARSIZ gösterilir.
  if (best > 3.5f || separation < 0.12f || m.confidence < 48.0f) {
    return CLASS_UNCERTAIN;
  }
  return candidate;
}

static Measurement processMeasurement(const float raw[4], bool allowTrack) {
  Measurement m;

  if (!filterReady) {
    for (uint8_t g = 0; g < 4; g++) filteredGate[g] = raw[g];
    filterReady = true;
  } else {
    for (uint8_t g = 0; g < 4; g++) {
      filteredGate[g] += 0.28f * (raw[g] - filteredGate[g]);
    }
  }

  for (uint8_t g = 0; g < 4; g++) {
    m.gate[g] = filteredGate[g];
    m.delta[g] = fabsf(filteredGate[g] - baseline[g]);
  }

  m.magnitude = 0.42f * m.delta[0] + 0.30f * m.delta[1] +
                0.18f * m.delta[2] + 0.10f * m.delta[3];
  m.normalizedMagnitude = normalizeMagnitude(m.magnitude);

  float early = m.delta[0] + 0.75f * m.delta[1] + 2.0f;
  float late  = m.delta[2] + 1.25f * m.delta[3] + 1.0f;
  m.ratio = late / early;

  float featureTotal = m.delta[0] + m.delta[1] + m.delta[2] + m.delta[3] + 4.0f;
  for (uint8_t g = 0; g < 4; g++) {
    m.feature[g] = (m.delta[g] + 1.0f) / featureTotal;
  }
  m.feature[4] = m.ratio;
  m.classScore = 0.5f;
  m.confidence = 0.0f;
  m.bestProfile = -1;

  float threshold = currentDetectionThreshold();
  if (!baselineReady || m.magnitude < threshold) {
    m.targetClass = CLASS_NONE;
  } else {
    m.targetClass = classifyFromLearnedProfiles(m);
  }

  m.estimatedDepthCm = (m.targetClass == CLASS_NONE)
                           ? -1.0f
                           : estimateDepthCm(m.normalizedMagnitude);

  // Hedef yokken sıcaklık ve yavaş toprak kaymasını takip eder.
  if (allowTrack && settings.autoTrack && m.magnitude < threshold * 0.45f) {
    for (uint8_t g = 0; g < 4; g++) {
      baseline[g] += 0.0020f * (filteredGate[g] - baseline[g]);
    }
  }

  return m;
}

static void resetClassificationHistory() {
  for (uint8_t i = 0; i < CLASS_HISTORY_COUNT; i++) {
    classHistory[i] = CLASS_NONE;
  }
  classHistoryIndex = 0;
  classHistoryFilled = 0;
}

static void stabilizeClassification(Measurement &m) {
  TargetClass currentClass = m.targetClass;
  classHistory[classHistoryIndex] = m.targetClass;
  classHistoryIndex = (classHistoryIndex + 1) % CLASS_HISTORY_COUNT;
  if (classHistoryFilled < CLASS_HISTORY_COUNT) classHistoryFilled++;

  uint8_t votes[4] = {0, 0, 0, 0};
  for (uint8_t i = 0; i < classHistoryFilled; i++) {
    votes[(uint8_t)classHistory[i]]++;
  }

  uint8_t bestClass = CLASS_NONE;
  uint8_t bestVotes = votes[CLASS_NONE];
  for (uint8_t cls = CLASS_TRASH; cls <= CLASS_VALUABLE; cls++) {
    if (votes[cls] > bestVotes) {
      bestClass = cls;
      bestVotes = votes[cls];
    }
  }

  // Anlık ölçüm METAL YOK ise geçmiş oyları kullanarak hayalî bir hedefi
  // ekranda/seste sürdürme. Önceki sürümde bu durumda sınıf geri gelebiliyor,
  // fakat güven ve derinlik 0/ayarsız kalabiliyordu.
  if (currentClass == CLASS_NONE) {
    m.targetClass = CLASS_NONE;
    m.estimatedDepthCm = -1.0f;
    m.confidence = 0.0f;
    return;
  }

  // Geçmiş çoğunluğu anlık sınıftan farklıysa, önceki sınıfa ait güven
  // yüzdesini yeni bir sınıf etiketiyle göstermemek için KARARSIZ de.
  if (bestVotes >= 3 && bestClass == (uint8_t)currentClass) {
    m.targetClass = currentClass;
  } else {
    m.targetClass = CLASS_UNCERTAIN;
    if (m.confidence > 45.0f) m.confidence = 45.0f;
    m.bestProfile = -1;
    m.classScore = 0.5f;
  }

  if (m.targetClass == CLASS_NONE) {
    m.estimatedDepthCm = -1.0f;
    m.confidence = 0.0f;
  }
}

static Measurement measureBlock(bool allowTrack = true) {
  float raw[4];
  audioOff();
  readGateBlock(raw);
  return processMeasurement(raw, allowTrack);
}

static float readBatteryVoltage() {
  audioOff();
  uint32_t sum = 0;
  for (uint8_t i = 0; i < 16; i++) {
    sum += adcReadDirect(ADC_CH_BATTERY, 7);
  }
  (void)adcReadDirect(ADC_CH_SIGNAL, 2);
  float adc = (float)sum / 16.0f;
  return adc * ADC_VREF / 4095.0f * BAT_DIVIDER;
}

// -------------------------------------------------------------------------
// 10. TÜRKÇE EKRAN YARDIMCILARI
// -------------------------------------------------------------------------
static void useTurkishFont() {
  display.setFont(u8g2_font_unifont_t_latin);
}

static void drawFourLines(const char *line1, const char *line2,
                          const char *line3, const char *line4) {
  display.clearBuffer();
  useTurkishFont();
  if (line1) display.drawUTF8(0, 14, line1);
  if (line2) display.drawUTF8(0, 30, line2);
  if (line3) display.drawUTF8(0, 46, line3);
  if (line4) display.drawUTF8(0, 62, line4);
  display.sendBuffer();
}

static void showStartupLogo() {
  display.clearBuffer();
  display.drawFrame(0, 0, 128, 64);
  display.drawFrame(3, 3, 122, 58);

  display.setFont(u8g2_font_helvB12_tf);
  const char *logo = "MekanikAdam";
  int16_t logoX = (128 - (int16_t)display.getUTF8Width(logo)) / 2;
  if (logoX < 0) logoX = 0;
  display.drawUTF8(logoX, 27, logo);

  useTurkishFont();
  const char *subtitle = "PI Dedektörü";
  int16_t subtitleX = (128 - (int16_t)display.getUTF8Width(subtitle)) / 2;
  if (subtitleX < 0) subtitleX = 0;
  display.drawUTF8(subtitleX, 49, subtitle);
  display.sendBuffer();
  safeDelay(2000);
}

static const char *classText(TargetClass cls) {
  switch (cls) {
    case CLASS_TRASH:     return "DEĞERSİZ OLASI";
    case CLASS_UNCERTAIN: return "KARARSIZ";
    case CLASS_VALUABLE:  return "DEĞERLİ OLASI";
    default:              return "METAL YOK";
  }
}

static const char *coilName(uint8_t index) {
  static const char *names[COIL_PROFILE_COUNT] = {
    "AYAKKABI", "30 CM PI", "ÖZEL 1", "ÖZEL 2"
  };
  return index < COIL_PROFILE_COUNT ? names[index] : "BİLİNMİYOR";
}

static void drawMainScreen(const Measurement &m) {
  display.clearBuffer();
  useTurkishFont();
  display.drawUTF8(0, 14, "MekanikAdam PI");

  char line[32];
  float safeBattery = (isfinite(batteryVoltage) && batteryVoltage > 0.0f)
                          ? batteryVoltage : 0.0f;
  uint16_t batteryTenths = (uint16_t)(safeBattery * 10.0f + 0.5f);
  snprintf(line, sizeof(line), "%s P:%u.%uV", coilName(settings.activeCoil),
           (unsigned)(batteryTenths / 10U),
           (unsigned)(batteryTenths % 10U));
  display.drawUTF8(0, 30, line);
  display.drawUTF8(0, 46, classText(m.targetClass));

  const CoilProfile &coil = activeCoilProfileConst();
  unsigned signalValue = (unsigned)lroundf(fmaxf(0.0f, m.magnitude));
  if (m.targetClass == CLASS_NONE) {
    snprintf(line, sizeof(line), "S:%u D:--", signalValue);
  } else if (coil.depthPoints < 3 || m.estimatedDepthCm < 0.0f) {
    snprintf(line, sizeof(line), "S:%u D:AYARSIZ", signalValue);
  } else {
    uint8_t lastPoint = coil.depthPoints - 1;
    if (m.estimatedDepthCm > DEPTH_CM[lastPoint]) {
      snprintf(line, sizeof(line), "D:%u+ G:%u%%", DEPTH_CM[lastPoint],
               (unsigned)m.confidence);
    } else {
      unsigned depthValue =
          (unsigned)lroundf(fmaxf(0.0f, m.estimatedDepthCm));
      snprintf(line, sizeof(line), "D:%ucm G:%u%%", depthValue,
               (unsigned)lroundf(m.confidence));
    }
  }
  display.drawUTF8(0, 62, line);
  display.sendBuffer();
}

static void drawLowBattery() {
  char voltageLine[24];
  float safeBattery = (isfinite(batteryVoltage) && batteryVoltage > 0.0f)
                          ? batteryVoltage : 0.0f;
  uint16_t batteryHundredths = (uint16_t)(safeBattery * 100.0f + 0.5f);
  snprintf(voltageLine, sizeof(voltageLine), "Ölçülen:%u.%02u V",
           (unsigned)(batteryHundredths / 100U),
           (unsigned)(batteryHundredths % 100U));
  drawFourLines("PİL ÇOK DÜŞÜK", voltageLine,
                "CİHAZI KAPAT", "VE ŞARJ ET");
}

static void drawHardwareFault() {
  txLow();
  blankHigh();
  audioOff();
  if (timingFaultLatched) {
    drawFourLines("ZAMANLAMA HATASI", "TX KAPATILDI",
                  "CİHAZI KAPAT", "YAZILIMI KONTROL");
  } else {
    drawFourLines("ADC HATASI", "TX KAPATILDI",
                  "CİHAZI KAPAT", "PA0/PA4 KONTROL");
  }
}

// -------------------------------------------------------------------------
// 11. TOPRAK VE METAL REFERANS KALİBRASYONU
// -------------------------------------------------------------------------
static void calibrateGround() {
  audioOff();
  baselineReady = false;
  drawFourLines("BOBİNİ METALDEN", "UZAK TUT",
                "TOPRAK AYARI", "YAPILIYOR...");

  double mean[4] = {0, 0, 0, 0};
  double m2[4] = {0, 0, 0, 0};
  filterReady = false;
  for (uint8_t n = 0; n < 24; n++) {
    float raw[4];
    readGateBlock(raw);
    for (uint8_t g = 0; g < 4; g++) {
      double difference = raw[g] - mean[g];
      mean[g] += difference / (double)(n + 1);
      double difference2 = raw[g] - mean[g];
      m2[g] += difference * difference2;
    }
  }

  float standardDeviation[4];
  for (uint8_t g = 0; g < 4; g++) {
    baseline[g] = (float)mean[g];
    filteredGate[g] = baseline[g];
    standardDeviation[g] = sqrtf((float)(m2[g] / 23.0));
  }
  runtimeNoise = 0.42f * standardDeviation[0] +
                 0.30f * standardDeviation[1] +
                 0.18f * standardDeviation[2] +
                 0.10f * standardDeviation[3];
  if (!isfinite(runtimeNoise) || runtimeNoise < 0.0f) runtimeNoise = 0.0f;
  filterReady = true;
  baselineReady = true;
  resetClassificationHistory();
  safeDelay(250);
}

// -------------------------------------------------------------------------
// 12. ACEMİ DOSTU ÖĞRETME VE DERİNLİK YARDIMCILARI
// -------------------------------------------------------------------------

static WizardAction waitForOkOrMenu() {
  while (true) {
    if (buttonPressed(PIN_BTN_OK)) {
      waitButtonRelease(PIN_BTN_OK);
      return WIZARD_OK;
    }
    if (buttonPressed(PIN_BTN_MENU)) {
      waitButtonRelease(PIN_BTN_MENU);
      return WIZARD_CANCEL;
    }
    safeDelay(10);
  }
}

static void resetFilterToBaseline() {
  for (uint8_t g = 0; g < 4; g++) filteredGate[g] = baseline[g];
  filterReady = true;
}

static const char *teachTargetName(uint8_t index) {
  static const char *names[TARGET_PROFILE_COUNT + 1] = {
    "ALTIN 22/24", "ALTIN 14", "GÜMÜŞ 925", "ALÜM. FOLYO",
    "KUTU HALKASI", "BAKIR/PİRİNÇ", "DEMİR ÇİVİ", "BOŞ/METALSİZ"
  };
  return index <= TARGET_BLANK ? names[index] : "BİLİNMİYOR";
}

static const char *environmentName(uint8_t index) {
  static const char *names[ENV_COUNT] = {
    "HAVA", "KURU TOPRAK", "NEMLİ TOPRAK"
  };
  return index < ENV_COUNT ? names[index] : "BİLİNMİYOR";
}

static const char *orientationName(uint8_t index) {
  static const char *names[ORIENT_COUNT] = {
    "YATAY/PARALEL", "DİKEY/KENAR"
  };
  return index < ORIENT_COUNT ? names[index] : "BİLİNMİYOR";
}

static bool selectNamedOption(const char *title,
                              const char *(*nameFunction)(uint8_t),
                              uint8_t optionCount,
                              uint8_t &selection) {
  if (selection >= optionCount) selection = 0;
  while (true) {
    char countLine[24];
    snprintf(countLine, sizeof(countLine), "SEÇİM %u/%u",
             selection + 1, optionCount);
    drawFourLines(title, nameFunction(selection), countLine,
                  "YUK/AŞA OK M:ÇIK");

    if (buttonPressed(PIN_BTN_UP)) {
      waitButtonRelease(PIN_BTN_UP);
      selection = selection == 0 ? optionCount - 1 : selection - 1;
    }
    if (buttonPressed(PIN_BTN_DOWN)) {
      waitButtonRelease(PIN_BTN_DOWN);
      selection = (selection + 1) % optionCount;
    }
    if (buttonPressed(PIN_BTN_OK)) {
      waitButtonRelease(PIN_BTN_OK);
      return true;
    }
    if (buttonPressed(PIN_BTN_MENU)) {
      waitButtonRelease(PIN_BTN_MENU);
      return false;
    }
    safeDelay(10);
  }
}

static const char *coilNameForSelection(uint8_t index) {
  return coilName(index);
}

static bool selectDepthOption(uint8_t &selection) {
  if (selection >= DEPTH_POINT_COUNT) selection = 0;
  while (true) {
    char distanceLine[24];
    char countLine[24];
    snprintf(distanceLine, sizeof(distanceLine), "%u CM", DEPTH_CM[selection]);
    snprintf(countLine, sizeof(countLine), "SEÇİM %u/%u",
             selection + 1, DEPTH_POINT_COUNT);
    drawFourLines("HEDEF MESAFESİ", distanceLine, countLine,
                  "YUK/AŞA OK M:ÇIK");

    if (buttonPressed(PIN_BTN_UP)) {
      waitButtonRelease(PIN_BTN_UP);
      selection = selection == 0 ? DEPTH_POINT_COUNT - 1 : selection - 1;
    }
    if (buttonPressed(PIN_BTN_DOWN)) {
      waitButtonRelease(PIN_BTN_DOWN);
      selection = (selection + 1) % DEPTH_POINT_COUNT;
    }
    if (buttonPressed(PIN_BTN_OK)) {
      waitButtonRelease(PIN_BTN_OK);
      return true;
    }
    if (buttonPressed(PIN_BTN_MENU)) {
      waitButtonRelease(PIN_BTN_MENU);
      return false;
    }
    safeDelay(10);
  }
}

static void runningStatsReset(RunningStats &stats) {
  memset(&stats, 0, sizeof(stats));
}

static bool featureVectorFinite(const float feature[FEATURE_COUNT]) {
  for (uint8_t f = 0; f < FEATURE_COUNT; f++) {
    if (!isfinite(feature[f])) return false;
  }
  return true;
}

static void runningStatsAdd(RunningStats &stats,
                            const float feature[FEATURE_COUNT]) {
  stats.count++;
  for (uint8_t f = 0; f < FEATURE_COUNT; f++) {
    float difference = feature[f] - stats.mean[f];
    stats.mean[f] += difference / (float)stats.count;
    float difference2 = feature[f] - stats.mean[f];
    stats.m2[f] += difference * difference2;
  }
}

static void mergeTeachingSession(FeatureProfile &destination,
                                 const RunningStats &session,
                                 uint8_t environment,
                                 uint8_t orientation,
                                 uint8_t distanceIndex) {
  if (destination.count > 60000U) {
    uint16_t oldSessions = destination.sessions;
    memset(&destination, 0, sizeof(destination));
    destination.sessions = oldSessions;
  }

  if (destination.count == 0) {
    destination.count = session.count;
    for (uint8_t f = 0; f < FEATURE_COUNT; f++) {
      destination.mean[f] = session.mean[f];
      destination.m2[f] = session.m2[f];
    }
  } else {
    uint32_t oldCount = destination.count;
    uint32_t newCount = session.count;
    uint32_t totalCount = oldCount + newCount;
    for (uint8_t f = 0; f < FEATURE_COUNT; f++) {
      float difference = session.mean[f] - destination.mean[f];
      destination.mean[f] += difference * (float)newCount / (float)totalCount;
      destination.m2[f] += session.m2[f] +
          difference * difference * (float)oldCount * (float)newCount /
          (float)totalCount;
    }
    destination.count = (uint16_t)totalCount;
  }

  if (destination.sessions < 65535U) destination.sessions++;
  destination.environmentMask |= (uint8_t)(1U << environment);
  destination.orientationMask |= (uint8_t)(1U << orientation);
  destination.distanceMask |= (uint16_t)(1U << distanceIndex);
}

static bool teachTargetWizard() {
  drawFourLines("HEDEF ÖĞRETME", "20 KEZ ÖLÇÜLÜR",
                "18 ALGILAMA GEREK", "OK:BAŞLA M:ÇIK");
  if (waitForOkOrMenu() == WIZARD_CANCEL) return false;

  uint8_t target = TARGET_GOLD_22_24;
  uint8_t environment = ENV_AIR;
  uint8_t orientation = ORIENT_HORIZONTAL;
  uint8_t distanceIndex = 0;
  if (!selectNamedOption("ÖĞRETİLECEK", teachTargetName,
                         TARGET_PROFILE_COUNT + 1, target)) return false;
  if (!selectNamedOption("TEST ORTAMI", environmentName,
                         ENV_COUNT, environment)) return false;
  if (target != TARGET_BLANK) {
    if (!selectNamedOption("HEDEF DURUŞU", orientationName,
                           ORIENT_COUNT, orientation)) return false;
    if (!selectDepthOption(distanceIndex)) return false;
  }

  drawFourLines("HEDEFİ UZAĞA AL", "BOBİN METALSİZ",
                "ÖNCE TOPRAK AYAR", "OK:AYAR M:ÇIK");
  if (waitForOkOrMenu() == WIZARD_CANCEL) return false;
  calibrateGround();

  char placementLine[24];
  if (target == TARGET_BLANK) {
    snprintf(placementLine, sizeof(placementLine), "METALİ UZAK TUT");
    drawFourLines("BOŞ ALAN TESTİ", environmentName(environment),
                  placementLine, "OK:ÖLÇ M:ÇIK");
  } else {
    const char *shortOrientation = orientation == ORIENT_HORIZONTAL
                                       ? "YATAY" : "DİKEY";
    snprintf(placementLine, sizeof(placementLine), "MES:%uCM %s",
             DEPTH_CM[distanceIndex], shortOrientation);
    drawFourLines(teachTargetName(target), environmentName(environment),
                  placementLine, "OK:ÖLÇ M:ÇIK");
  }
  if (waitForOkOrMenu() == WIZARD_CANCEL) return false;

  bool oldTrack = settings.autoTrack;
  settings.autoTrack = 0;
  resetFilterToBaseline();
  for (uint8_t warmup = 0; warmup < 4; warmup++) {
    (void)measureBlock(false);
  }

  RunningStats session;
  runningStatsReset(session);
  uint8_t hits = 0;
  for (uint8_t n = 0; n < TEACH_MEASUREMENT_COUNT; n++) {
    char progressLine[24];
    snprintf(progressLine, sizeof(progressLine), "ÖLÇÜM %u/%u",
             n + 1, TEACH_MEASUREMENT_COUNT);
    drawFourLines(target == TARGET_BLANK ? "BOŞ TEST" : teachTargetName(target),
                  "HİÇ OYNATMA", progressLine, "BEKLEYİN...");
    Measurement measured = measureBlock(false);
    bool detected = measured.magnitude >= currentDetectionThreshold();
    if (detected) {
      hits++;
      if (target != TARGET_BLANK && featureVectorFinite(measured.feature)) {
        runningStatsAdd(session, measured.feature);
      }
    }
  }
  settings.autoTrack = oldTrack;
  resetClassificationHistory();

  bool accepted = false;
  if (target == TARGET_BLANK) {
    accepted = hits <= TEACH_BLANK_MAX_FALSE;
    if (accepted) {
      CoilProfile &coil = activeCoilProfile();
      if (coil.blankSessions < 65535U) coil.blankSessions++;
      coil.lastBlankFalse = hits;
      coil.blankEnvironmentMask |= (uint8_t)(1U << environment);
      settingsDirty = true;
    }
  } else {
    accepted = hits >= TEACH_TARGET_MIN_HITS &&
               session.count >= TEACH_TARGET_MIN_HITS;
    if (accepted) {
      mergeTeachingSession(activeCoilProfile().targets[target], session,
                           environment, orientation, distanceIndex);
      settingsDirty = true;
    }
  }

  bool saved = true;
  if (accepted) saved = saveSettings();
  char resultLine[24];
  if (target == TARGET_BLANK) {
    snprintf(resultLine, sizeof(resultLine), "YANLIŞ:%u/20", hits);
  } else {
    snprintf(resultLine, sizeof(resultLine), "ALGILAMA:%u/20", hits);
  }
  drawFourLines(accepted ? "TEST KABUL" : "TEST BAŞARISIZ",
                resultLine,
                accepted ? (saved ? "HAFIZAYA KAYITLI" : "HAFIZA HATASI")
                         : "KAYIT YAPILMADI",
                "OK/MENÜ:DEVAM");
  (void)waitForOkOrMenu();
  return accepted && saved;
}

static bool captureDepthStrength(float &strength, uint8_t &hits) {
  resetFilterToBaseline();
  for (uint8_t warmup = 0; warmup < 4; warmup++) {
    (void)measureBlock(false);
  }

  float sum = 0.0f;
  uint8_t valid = 0;
  hits = 0;
  for (uint8_t n = 0; n < TEACH_MEASUREMENT_COUNT; n++) {
    Measurement measured = measureBlock(false);
    if (isfinite(measured.normalizedMagnitude) &&
        measured.magnitude >= currentDetectionThreshold()) {
      sum += measured.normalizedMagnitude;
      valid++;
      hits++;
    }
  }

  if (valid < TEACH_TARGET_MIN_HITS) return false;
  strength = sum / (float)valid;
  // strength batarya gerilimine göre normalize edilmiştir; ham ADC eşiğiyle
  // tekrar karşılaştırmak özellikle 12 V üstünde geçerli bir noktayı yanlış
  // reddedebilirdi. Ham eşik zaten yukarıdaki her ölçümde uygulanmıştır.
  return isfinite(strength) && strength > 0.0f;
}

static bool copyDepthCalibration(const float values[DEPTH_POINT_COUNT],
                                 uint8_t count) {
  CoilProfile &coil = activeCoilProfile();
  coil.depthPoints = count;
  for (uint8_t i = 0; i < DEPTH_POINT_COUNT; i++) {
    coil.depthStrength[i] = (i < count) ? values[i] : 0.0f;
  }
  settingsDirty = true;
  return saveSettings();
}

static bool finishPartialDepth(const float values[DEPTH_POINT_COUNT],
                               uint8_t count, bool oldTrack) {
  settings.autoTrack = oldTrack;
  if (count < 3) {
    drawFourLines("EN AZ 3 NOKTA", "GEREKLİDİR",
                  "KAYIT YAPILMADI", nullptr);
    safeDelay(1200);
    return false;
  }
  bool saved = copyDepthCalibration(values, count);
  char limitLine[24];
  snprintf(limitLine, sizeof(limitLine), "SON SINIR:%u CM", DEPTH_CM[count - 1]);
  drawFourLines(saved ? "KISMİ AYAR KAYDI" : "HAFIZA HATASI",
                limitLine, "ÖTESİ YAKLAŞIK", nullptr);
  safeDelay(1400);
  return saved;
}

static bool calibrateDepthWizard() {
  bool oldTrack = settings.autoTrack;
  settings.autoTrack = 0;

  drawFourLines("DERİNLİK AYARI", "1 TL PARA KULLAN",
                "HER NOKTA 18/20", "OK:DEVAM M:ÇIK");
  if (waitForOkOrMenu() == WIZARD_CANCEL) {
    settings.autoTrack = oldTrack;
    return false;
  }

  drawFourLines("PARAYI UZAK TUT", "BOBİN METALSİZ",
                "TOPRAK AYARI", "OK:BAŞLA M:ÇIK");
  if (waitForOkOrMenu() == WIZARD_CANCEL) {
    settings.autoTrack = oldTrack;
    return false;
  }
  calibrateGround();

  float newStrength[DEPTH_POINT_COUNT] = {0};
  uint8_t captured = 0;

  while (captured < DEPTH_POINT_COUNT) {
    char distanceLine[24];
    snprintf(distanceLine, sizeof(distanceLine), "%u CM UZAKLIKTA",
             DEPTH_CM[captured]);
    drawFourLines("1 TL PARAYI TUT", distanceLine,
                  "BOBİNE PARALEL", "OK:ÖLÇ M:BİTİR");
    if (waitForOkOrMenu() == WIZARD_CANCEL) {
      return finishPartialDepth(newStrength, captured, oldTrack);
    }

    drawFourLines("PARAYI OYNATMA", distanceLine,
                  "20 ÖLÇÜM", "BEKLEYİN...");
    float measuredStrength = 0.0f;
    uint8_t hits = 0;
    bool strongEnough = captureDepthStrength(measuredStrength, hits);
    bool descending = captured == 0 ||
                      measuredStrength < newStrength[captured - 1] * 0.985f;

    if (!strongEnough) {
      char hitsLine[24];
      snprintf(hitsLine, sizeof(hitsLine), "ALGILAMA:%u/20", hits);
      drawFourLines("SİNYAL YETERSİZ", hitsLine,
                    "OK:TEKRAR", "MENÜ:BİTİR");
      if (waitForOkOrMenu() == WIZARD_CANCEL) {
        return finishPartialDepth(newStrength, captured, oldTrack);
      }
      continue;
    }

    if (!descending) {
      drawFourLines("MESAFE HATASI", "UZAKLAŞTIKÇA",
                    "SİNYAL AZALMALI", "OK:YİNE M:BİTİR");
      if (waitForOkOrMenu() == WIZARD_CANCEL) {
        return finishPartialDepth(newStrength, captured, oldTrack);
      }
      continue;
    }

    newStrength[captured] = measuredStrength;
    char savedLine[24];
    snprintf(savedLine, sizeof(savedLine), "%u CM: %u/20",
             DEPTH_CM[captured], hits);
    captured++;
    drawFourLines("NOKTA KABUL", savedLine,
                  captured < DEPTH_POINT_COUNT ? "SONRAKİ NOKTA" : "TÜMÜ TAMAM",
                  "HAZIRLANIYOR...");
    safeDelay(800);
  }

  settings.autoTrack = oldTrack;
  bool saved = copyDepthCalibration(newStrength, DEPTH_POINT_COUNT);
  drawFourLines(saved ? "DERİNLİK KAYITLI" : "HAFIZA HATASI",
                "SON SINIR:50 CM", "1 TL İÇİN TAHMİN", nullptr);
  safeDelay(1400);
  return saved;
}

// Bobin takılı değilken PT2257 -> LM386 -> hoparlör/kulaklık ses yolunu
// güvenli biçimde sınamak için üç gerçek cihaz tonu çalar. Test boyunca
// verici darbesi kesin olarak kapalı, blanking ise güvenli durumda tutulur.
static void playAudioTestStep(const char *stepName, uint16_t frequency) {
  txLow();
  blankHigh();
  audioOff();

  char frequencyLine[18];
  snprintf(frequencyLine, sizeof(frequencyLine), "%u HZ", frequency);
  drawFourLines("SES TESTİ", stepName, frequencyLine, "TX KAPALI");
  safeDelay(250);

  tone(PIN_AUDIO, frequency);
  safeDelay(800);
  audioOff();
  safeDelay(250);
}

static void runAudioTest() {
  // Her çıkış yolunda MOSFET sürmesini güvenli durumda bırak.
  txLow();
  blankHigh();
  audioOff();

  if (settings.volumeLevel == 0) {
    drawFourLines("SES KAPALI", "SES SEVİYESİNİ", "EN AZ 3 YAP", "SONRA YİNE DENE");
    safeDelay(1800);
    return;
  }

  pt2257Present = applyVolumeLevel();
  if (!pt2257Present) {
    drawFourLines("PT2257 HATASI", "SES TESTİ DURDU",
                  "SDA/SCL KONTROL", "BESLEME: 3,3V");
    safeDelay(2000);
    return;
  }

  playAudioTestStep("1/3 KALIN SES", 300);
  playAudioTestStep("2/3 ORTA SES", 650);
  playAudioTestStep("3/3 İNCE SES", 1250);

  audioOff();
  txLow();
  blankHigh();
  drawFourLines("SES TESTİ TAMAM", "3 TON DUYDUN MU?",
                "SES YOKSA MENÜ", "SEVİYEYİ YÜKSELT");
  safeDelay(1800);
}

// -------------------------------------------------------------------------
// 12B. TANI EKRANI VE KAPI TARAMASI (Rev7.1) - osiloskopsuz teşhis
// -------------------------------------------------------------------------
// Bu bölüm normal ölçümü değiştirmez; yalnız menüden çalıştırılır.
// Darbe süresi (80 µs) ve tekrar hızı aynıdır. Yalnız örnekleme anları ve
// ekrana yazılan değerler farklıdır. Ekran metinleri bilinçli olarak ASCII'dir.

static ScanResult scanCurrent;
static ScanResult scanReference;
static uint8_t scanCount = 0;

// Tanı modlarına girmeden önce pil ve donanım durumunu kontrol eder.
static bool diagPreflight() {
  audioOff();
  batteryVoltage = readBatteryVoltage();
  lastBatteryMs = millis();
  if (adcFaultLatched || timingFaultLatched) {
    drawHardwareFault();
    safeDelay(1500);
    return false;
  }
  if (!isfinite(batteryVoltage) || batteryVoltage < LOW_BATTERY_CUTOFF_V) {
    lowBatteryLatched = true;
    drawLowBattery();
    safeDelay(1500);
    return false;
  }
  return true;
}

// Üretim darbesiyle aynı sıra; yalnız ilk kapı, kapı aralığı ve blank
// bırakma anı parametredir.
static bool acquirePulseCustom(uint16_t out[4], uint16_t firstGateUs,
                               uint16_t gateStepUs, uint16_t blankReleaseUs) {
  uint32_t frameStart = DWT->CYCCNT;

  blankHigh();
  txHigh();
  if (!waitUntilCycle(frameStart + usToCycles(PULSE_US))) {
    txLow();
    blankHigh();
    timingFaultLatched = true;
    return false;
  }
  txLow();
  uint32_t pulseOff = frameStart + usToCycles(PULSE_US);

  if (!waitUntilCycle(pulseOff + usToCycles(blankReleaseUs))) {
    txLow();
    blankHigh();
    timingFaultLatched = true;
    return false;
  }
  blankLow();

  for (uint8_t i = 0; i < 4; i++) {
    uint16_t gate = (uint16_t)(firstGateUs + (uint16_t)i * gateStepUs);
    if (!waitUntilCycle(pulseOff + usToCycles(gate))) {
      txLow();
      blankHigh();
      timingFaultLatched = true;
      return false;
    }
    out[i] = adcReadDirect(ADC_CH_SIGNAL, 2);
    if (adcFaultLatched) {
      txLow();
      blankHigh();
      return false;
    }
  }

  blankHigh();
  return true;
}

// 32 noktalı sönüm taraması: her darbede 4 nokta, 16 darbe ortalaması.
static bool runScan(ScanResult &result, uint16_t startUs, uint16_t blankUs) {
  audioOff();
  result.startUs = startUs;
  result.blankUs = blankUs;
  result.rails = 0;

  for (uint8_t group = 0; group < SCAN_POINTS / 4; group++) {
    uint16_t firstGate =
        (uint16_t)(startUs + (uint16_t)group * 4U * SCAN_STEP_US);
    uint32_t sum[4] = {0, 0, 0, 0};
    uint16_t lowest[4] = {4095, 4095, 4095, 4095};
    uint16_t highest[4] = {0, 0, 0, 0};

    for (uint8_t pulse = 0; pulse < SCAN_PULSES; pulse++) {
      wdtFeed();
      uint32_t pulseStartUs = micros();
      uint16_t sample[4];

      noInterrupts();
      bool pulseOk =
          acquirePulseCustom(sample, firstGate, SCAN_STEP_US, blankUs);
      interrupts();

      if (!pulseOk) {
        txLow();
        blankHigh();
        return false;
      }

      for (uint8_t k = 0; k < 4; k++) {
        sum[k] += sample[k];
        if (sample[k] < lowest[k]) lowest[k] = sample[k];
        if (sample[k] > highest[k]) highest[k] = sample[k];
        if (sample[k] <= ADC_RAIL_LOW || sample[k] >= ADC_RAIL_HIGH) {
          result.rails++;
        }
      }

      while ((uint32_t)(micros() - pulseStartUs) < PULSE_PERIOD_US) {
        delayMicroseconds(20);
      }
    }

    for (uint8_t k = 0; k < 4; k++) {
      uint8_t index = (uint8_t)(group * 4U + k);
      result.mean[index] = (float)sum[k] / (float)SCAN_PULSES;
      result.minValue[index] = lowest[k];
      result.maxValue[index] = highest[k];
    }
  }
  return true;
}

static bool performScan(uint16_t startUs, uint16_t blankUs) {
  drawFourLines("TARAMA SURUYOR", "HEDEFI/BOBINI", "OYNATMA", "BEKLEYIN...");
  if (!runScan(scanCurrent, startUs, blankUs)) {
    drawHardwareFault();
    safeDelay(1500);
    return false;
  }
  if (scanCount == 0) scanReference = scanCurrent;
  if (scanCount < 255) scanCount++;
  return true;
}

static uint16_t scanTimeUs(uint8_t index) {
  return (uint16_t)(scanCurrent.startUs + (uint16_t)index * SCAN_STEP_US);
}

static void drawScanGraph(bool diffMode) {
  float value[SCAN_POINTS];
  uint16_t maxPp = 0;
  for (uint8_t i = 0; i < SCAN_POINTS; i++) {
    value[i] = diffMode ? (scanCurrent.mean[i] - scanReference.mean[i])
                        : scanCurrent.mean[i];
    uint16_t pp = (uint16_t)(scanCurrent.maxValue[i] - scanCurrent.minValue[i]);
    if (pp > maxPp) maxPp = pp;
  }

  float realLow = value[0];
  float realHigh = value[0];
  for (uint8_t i = 1; i < SCAN_POINTS; i++) {
    if (value[i] < realLow) realLow = value[i];
    if (value[i] > realHigh) realHigh = value[i];
  }
  float low = realLow;
  float high = realHigh;
  if ((high - low) < 8.0f) {
    float middle = 0.5f * (high + low);
    low = middle - 4.0f;
    high = middle + 4.0f;
  }
  float span = high - low;

  char header[32];
  if (diffMode) {
    snprintf(header, sizeof(header), "FARK#%u H%+d L%+d", (unsigned)scanCount,
             (int)lroundf(realHigh), (int)lroundf(realLow));
  } else {
    snprintf(header, sizeof(header), "%uus H%d L%d N%u",
             (unsigned)scanCurrent.startUs, (int)lroundf(realHigh),
             (int)lroundf(realLow), (unsigned)maxPp);
  }

  const int plotTop = 16;
  const int plotBottom = 58;

  display.clearBuffer();
  display.setFont(u8g2_font_6x12_tf);
  display.drawStr(0, 11, header);

  int previousX = 0;
  int previousY = 0;
  for (uint8_t i = 0; i < SCAN_POINTS; i++) {
    int x = (int)i * SCAN_STEP_US;
    int y = plotBottom -
            (int)lroundf((value[i] - low) / span * (float)(plotBottom - plotTop));
    if (y < plotTop) y = plotTop;
    if (y > plotBottom) y = plotBottom;
    if (i == 0) {
      display.drawPixel(x, y);
    } else {
      display.drawLine(previousX, previousY, x, y);
    }
    previousX = x;
    previousY = y;
  }

  if (diffMode && low < 0.0f && high > 0.0f) {
    int zeroY = plotBottom -
                (int)lroundf((0.0f - low) / span * (float)(plotBottom - plotTop));
    for (int x = 0; x < 128; x += 4) display.drawPixel(x, zeroY);
  }

  // Alt cetvel: her 20 piksel = 20 mikrosaniye (1 piksel = 1 us).
  for (int x = 0; x < 128; x += 20) display.drawVLine(x, 60, 4);
  display.sendBuffer();
}

static void drawScanTable(bool diffMode, uint8_t chunk) {
  uint8_t firstIndex = (uint8_t)(chunk * 8U);
  char header[32];
  snprintf(header, sizeof(header), "%s %u-%uus %u/4", diffMode ? "FARK" : "HAM",
           (unsigned)scanTimeUs(firstIndex),
           (unsigned)scanTimeUs((uint8_t)(firstIndex + 7)),
           (unsigned)(chunk + 1));

  display.clearBuffer();
  display.setFont(u8g2_font_6x12_tf);
  display.drawStr(0, 11, header);

  for (uint8_t row = 0; row < 4; row++) {
    uint8_t first = (uint8_t)(firstIndex + row * 2U);
    uint8_t second = (uint8_t)(first + 1U);
    int firstValue;
    int secondValue;
    char line[32];
    if (diffMode) {
      firstValue = (int)lroundf(scanCurrent.mean[first] - scanReference.mean[first]);
      secondValue = (int)lroundf(scanCurrent.mean[second] - scanReference.mean[second]);
      snprintf(line, sizeof(line), "%u:%+d  %u:%+d", (unsigned)scanTimeUs(first),
               firstValue, (unsigned)scanTimeUs(second), secondValue);
    } else {
      firstValue = (int)lroundf(scanCurrent.mean[first]);
      secondValue = (int)lroundf(scanCurrent.mean[second]);
      snprintf(line, sizeof(line), "%u:%d  %u:%d", (unsigned)scanTimeUs(first),
               firstValue, (unsigned)scanTimeUs(second), secondValue);
    }
    display.drawStr(0, (uint8_t)(24 + row * 13), line);
  }
  display.sendBuffer();
}

static void drawScanPage(uint8_t page) {
  bool hasDifference = (scanCount >= 2);
  if (page == 0) {
    drawScanGraph(false);
  } else if (page == 1) {
    if (hasDifference) {
      drawScanGraph(true);
    } else {
      drawFourLines("FARK YOK", "ILK OLCUM", "REFERANS ALINDI", "OK:2. OLCUM");
    }
  } else if (page < 6) {
    drawScanTable(false, (uint8_t)(page - 2));
  } else {
    if (hasDifference) {
      drawScanTable(true, (uint8_t)(page - 6));
    } else {
      drawFourLines("FARK YOK", "ILK OLCUM", "REFERANS ALINDI", "OK:2. OLCUM");
    }
  }
}

static void runGateScan() {
  if (!diagPreflight()) return;

  uint8_t mode = 0;  // 0 = uretim zamanlamasi, 1 = erken blank
  bool redraw = true;
  while (true) {
    wdtFeed();
    if (redraw) {
      drawFourLines("KAPI TARAMASI",
                    mode == 0 ? "MOD:URETIM" : "MOD:ERKEN",
                    mode == 0 ? "BLANK 28us ILK30" : "BLANK 8us ILK10",
                    "UST/ALT OK M:CIK");
      redraw = false;
    }
    if (buttonPressed(PIN_BTN_UP)) {
      waitButtonRelease(PIN_BTN_UP);
      mode = (uint8_t)(1 - mode);
      redraw = true;
    }
    if (buttonPressed(PIN_BTN_DOWN)) {
      waitButtonRelease(PIN_BTN_DOWN);
      mode = (uint8_t)(1 - mode);
      redraw = true;
    }
    if (buttonPressed(PIN_BTN_MENU)) {
      waitButtonRelease(PIN_BTN_MENU);
      return;
    }
    if (buttonPressed(PIN_BTN_OK)) {
      waitButtonRelease(PIN_BTN_OK);
      break;
    }
    safeDelay(10);
  }

  uint16_t startUs =
      (mode == 0) ? SCAN_START_PRODUCTION_US : SCAN_START_EARLY_US;
  uint16_t blankUs = (mode == 0) ? BLANK_RELEASE_US : SCAN_BLANK_EARLY_US;
  scanCount = 0;

  if (!performScan(startUs, blankUs)) return;

  uint8_t page = 0;
  redraw = true;
  while (true) {
    wdtFeed();
    if (redraw) {
      drawScanPage(page);
      redraw = false;
    }
    if (buttonPressed(PIN_BTN_MENU)) {
      waitButtonRelease(PIN_BTN_MENU);
      break;
    }
    if (buttonPressed(PIN_BTN_UP)) {
      waitButtonRelease(PIN_BTN_UP);
      page = (page == 0) ? (uint8_t)(SCAN_PAGE_COUNT - 1) : (uint8_t)(page - 1);
      redraw = true;
    }
    if (buttonPressed(PIN_BTN_DOWN)) {
      waitButtonRelease(PIN_BTN_DOWN);
      page = (uint8_t)((page + 1) % SCAN_PAGE_COUNT);
      redraw = true;
    }
    if (buttonPressed(PIN_BTN_OK)) {
      waitButtonRelease(PIN_BTN_OK);
      if (!performScan(startUs, blankUs)) break;
      redraw = true;
    }
    safeDelay(10);
  }

  txLow();
  blankHigh();
  audioOff();
}

// Üretim kapılarıyla 16 darbe: ortalama, tepeden tepeye ve ray sayısı.
static bool collectLiveStats(LiveStats &stats) {
  uint32_t sum[4] = {0, 0, 0, 0};
  uint16_t lowest[4] = {4095, 4095, 4095, 4095};
  uint16_t highest[4] = {0, 0, 0, 0};
  stats.rails = 0;

  for (uint8_t pulse = 0; pulse < 16; pulse++) {
    wdtFeed();
    uint32_t pulseStartUs = micros();
    uint16_t sample[4];

    noInterrupts();
    bool pulseOk = acquireOnePulse(sample);
    interrupts();

    if (!pulseOk) {
      txLow();
      blankHigh();
      return false;
    }
    for (uint8_t g = 0; g < 4; g++) {
      sum[g] += sample[g];
      if (sample[g] < lowest[g]) lowest[g] = sample[g];
      if (sample[g] > highest[g]) highest[g] = sample[g];
      if (sample[g] <= ADC_RAIL_LOW || sample[g] >= ADC_RAIL_HIGH) {
        stats.rails++;
      }
    }
    while ((uint32_t)(micros() - pulseStartUs) < PULSE_PERIOD_US) {
      delayMicroseconds(20);
    }
  }

  for (uint8_t g = 0; g < 4; g++) {
    stats.mean[g] = (float)sum[g] / 16.0f;
    stats.pp[g] = (uint16_t)(highest[g] - lowest[g]);
  }
  return true;
}

static unsigned capPp(uint16_t value) {
  return value > 999 ? 999U : (unsigned)value;
}

static void drawLiveDiagnostics(uint8_t page, const LiveStats &stats) {
  char line1[28];
  char line2[28];
  char line3[28];
  char line4[28];

  if (page == 0) {
    uint16_t tenths = (uint16_t)(batteryVoltage * 10.0f + 0.5f);
    snprintf(line1, sizeof(line1), "TANI 1/2 P%u.%uV", (unsigned)(tenths / 10U),
             (unsigned)(tenths % 10U));
    snprintf(line2, sizeof(line2), "%u:%d %u:%d", (unsigned)GATE_US[0],
             (int)lroundf(stats.mean[0]), (unsigned)GATE_US[1],
             (int)lroundf(stats.mean[1]));
    snprintf(line3, sizeof(line3), "%u:%d %u:%d", (unsigned)GATE_US[2],
             (int)lroundf(stats.mean[2]), (unsigned)GATE_US[3],
             (int)lroundf(stats.mean[3]));
    snprintf(line4, sizeof(line4), "P%u %u %u %u R%u", capPp(stats.pp[0]),
             capPp(stats.pp[1]), capPp(stats.pp[2]), capPp(stats.pp[3]),
             (unsigned)stats.rails);
    drawFourLines(line1, line2, line3, line4);
    return;
  }

  if (!baselineReady) {
    drawFourLines("TANI 2/2 FARK", "TOPRAK AYARI", "YAPILMAMIS", "MENUDEN YAP");
    return;
  }

  float delta[4];
  for (uint8_t g = 0; g < 4; g++) delta[g] = stats.mean[g] - baseline[g];
  float magnitude = 0.42f * fabsf(delta[0]) + 0.30f * fabsf(delta[1]) +
                    0.18f * fabsf(delta[2]) + 0.10f * fabsf(delta[3]);

  snprintf(line1, sizeof(line1), "TANI 2/2 FARK");
  snprintf(line2, sizeof(line2), "d1:%+d d2:%+d", (int)lroundf(delta[0]),
           (int)lroundf(delta[1]));
  snprintf(line3, sizeof(line3), "d3:%+d d4:%+d", (int)lroundf(delta[2]),
           (int)lroundf(delta[3]));
  snprintf(line4, sizeof(line4), "S:%d E:%d", (int)lroundf(magnitude),
           (int)lroundf(currentDetectionThreshold()));
  drawFourLines(line1, line2, line3, line4);
}

static void runLiveDiagnostics() {
  if (!diagPreflight()) return;

  drawFourLines("TANI EKRANI", "UST/ALT:SAYFA", "MENU:CIKIS", "OLCUYOR...");
  safeDelay(700);

  uint8_t page = 0;
  uint32_t lastBatteryCheck = millis();
  while (true) {
    wdtFeed();
    if (buttonPressed(PIN_BTN_MENU)) {
      waitButtonRelease(PIN_BTN_MENU);
      break;
    }
    bool pageKey = false;
    if (buttonPressed(PIN_BTN_UP)) {
      waitButtonRelease(PIN_BTN_UP);
      pageKey = true;
    }
    if (buttonPressed(PIN_BTN_DOWN)) {
      waitButtonRelease(PIN_BTN_DOWN);
      pageKey = true;
    }
    if (pageKey) page = (uint8_t)(1 - page);

    if (millis() - lastBatteryCheck >= 1000) {
      batteryVoltage = readBatteryVoltage();
      lastBatteryCheck = millis();
      if (!isfinite(batteryVoltage) || batteryVoltage < LOW_BATTERY_CUTOFF_V) {
        lowBatteryLatched = true;
        break;
      }
    }

    LiveStats stats;
    if (!collectLiveStats(stats)) {
      drawHardwareFault();
      safeDelay(1500);
      break;
    }
    drawLiveDiagnostics(page, stats);
  }

  txLow();
  blankHigh();
  audioOff();
}

// -------------------------------------------------------------------------
// 13. MENÜ
// -------------------------------------------------------------------------
static const uint8_t MENU_ITEM_COUNT = 13;

static const char *menuName(uint8_t index) {
  static const char *items[MENU_ITEM_COUNT] = {
    "HASSASİYET",
    "SES SEVİYESİ",
    "OTOMATİK TOPRAK",
    "BOBİN PROFİLİ",
    "TOPRAK AYARI",
    "HEDEF ÖĞRET",
    "DERİNLİK AYARI",
    "PROFİL DURUMU",
    "BİP SÜRESİ",
    "SES TESTİ",
    "TANI EKRANI",
    "KAPI TARAMASI",
    "KAYDET VE ÇIK"
  };
  return items[index];
}

static uint8_t learnedTargetCount(const CoilProfile &coil) {
  uint8_t learned = 0;
  for (uint8_t target = 0; target < TARGET_PROFILE_COUNT; target++) {
    if (targetProfileLearned(coil.targets[target])) learned++;
  }
  return learned;
}

static void drawMenu(const char *status = nullptr) {
  display.clearBuffer();
  useTurkishFont();
  display.drawUTF8(0, 14, editMode ? "AYARLA:OK BİTİR" : "MENÜ:OK SEÇ");
  display.drawHLine(0, 17, 128);
  display.drawUTF8(0, 32, menuName(menuIndex));

  char value[32] = "";
  if (menuIndex == 0) {
    snprintf(value, sizeof(value), "Değer:%u/10", settings.sensitivity);
  } else if (menuIndex == 1) {
    snprintf(value, sizeof(value), "Değer:%u/10", settings.volumeLevel);
  } else if (menuIndex == 2) {
    snprintf(value, sizeof(value), "Değer:%s",
             settings.autoTrack ? "AÇIK" : "KAPALI");
  } else if (menuIndex == 3) {
    snprintf(value, sizeof(value), "%s", coilName(settings.activeCoil));
  } else if (menuIndex == 5) {
    snprintf(value, sizeof(value), "Öğretilen:%u/7",
             learnedTargetCount(activeCoilProfileConst()));
  } else if (menuIndex == 6) {
    const CoilProfile &coil = activeCoilProfileConst();
    if (coil.depthPoints >= 3) {
      snprintf(value, sizeof(value), "N:%u Son:%ucm",
               coil.depthPoints, DEPTH_CM[coil.depthPoints - 1]);
    } else {
      snprintf(value, sizeof(value), "Henüz ayarsız");
    }
  } else if (menuIndex == 7) {
    snprintf(value, sizeof(value), "OK ile görüntüle");
  } else if (menuIndex == 8) {
    snprintf(value, sizeof(value), "Değer:%u/8", settings.audioLength);
  } else if (menuIndex == 9) {
    snprintf(value, sizeof(value), "OK:3 TONU ÇAL");
  } else {
    snprintf(value, sizeof(value), "OK ile çalıştır");
  }

  display.drawUTF8(0, 47, value);
  display.drawUTF8(0, 63, status ? status : "MENÜ:GERİ/ÇIK");
  display.sendBuffer();
}

static void showTemporary(const char *message, uint16_t waitMs = 900) {
  drawMenu(message);
  safeDelay(waitMs);
}

static void showProfileStatus() {
  const CoilProfile &coil = activeCoilProfileConst();
  char coilLine[28];
  char targetLine[28];
  char depthLine[28];
  char blankLine[28];
  snprintf(coilLine, sizeof(coilLine), "BOBİN:%s", coilName(settings.activeCoil));
  snprintf(targetLine, sizeof(targetLine), "HEDEF:%u/7",
           learnedTargetCount(coil));
  if (coil.depthPoints >= 3) {
    snprintf(depthLine, sizeof(depthLine), "DERİNLİK:%u CM",
             DEPTH_CM[coil.depthPoints - 1]);
  } else {
    snprintf(depthLine, sizeof(depthLine), "DERİNLİK:AYARSIZ");
  }
  if (coil.blankSessions > 0) {
    snprintf(blankLine, sizeof(blankLine), "BOŞ:%u/20 YANLIŞ",
             coil.lastBlankFalse);
  } else {
    snprintf(blankLine, sizeof(blankLine), "BOŞ TEST:YOK");
  }
  drawFourLines(coilLine, targetLine, depthLine, blankLine);
  (void)waitForOkOrMenu();
}

static bool selectCoilProfileWizard() {
  drawFourLines("BOBİN DEĞİŞİMİ", "CİHAZ KAPALIYKEN",
                "YAPILMIŞ OLMALI", "OK:SEÇ M:ÇIK");
  if (waitForOkOrMenu() == WIZARD_CANCEL) return false;

  uint8_t selected = settings.activeCoil;
  if (!selectNamedOption("BOBİN PROFİLİ", coilNameForSelection,
                         COIL_PROFILE_COUNT, selected)) return false;
  if (selected == settings.activeCoil) return true;

  settings.activeCoil = selected;
  settingsDirty = true;
  bool saved = saveSettings();
  resetFilterToBaseline();
  resetClassificationHistory();
  drawFourLines(saved ? "PROFİL SEÇİLDİ" : "HAFIZA HATASI",
                coilName(settings.activeCoil), "BOBİNİ METALDEN",
                "UZAK TUT");
  safeDelay(900);
  calibrateGround();
  return saved;
}

static void handleMenu() {
  if (!menuOpen) {
    if (buttonPressed(PIN_BTN_MENU)) {
      waitButtonRelease(PIN_BTN_MENU);
      menuOpen = true;
      editMode = false;
      drawMenu();
    }
    return;
  }

  if (buttonPressed(PIN_BTN_MENU)) {
    waitButtonRelease(PIN_BTN_MENU);
    bool saved = !settingsDirty || saveSettings();
    menuOpen = false;
    editMode = false;
    if (!saved) {
      drawFourLines("HAFIZA HATASI", "AYAR KAYDI YOK",
                    "TEKRAR DENE", nullptr);
      safeDelay(1200);
    }
    return;
  }

  if (!editMode) {
    if (buttonPressed(PIN_BTN_UP)) {
      menuIndex = (menuIndex == 0) ? MENU_ITEM_COUNT - 1 : menuIndex - 1;
      drawMenu();
    }

    if (buttonPressed(PIN_BTN_DOWN)) {
      menuIndex = (menuIndex + 1) % MENU_ITEM_COUNT;
      drawMenu();
    }

    if (buttonPressed(PIN_BTN_OK)) {
      waitButtonRelease(PIN_BTN_OK);
      if (menuIndex == 0 || menuIndex == 1 ||
          menuIndex == 2 || menuIndex == 8) {
        editMode = true;
      } else if (menuIndex == 3) {
        (void)selectCoilProfileWizard();
      } else if (menuIndex == 4) {
        calibrateGround();
        showTemporary("TOPRAK TAMAM");
      } else if (menuIndex == 5) {
        bool teachingSaved = teachTargetWizard();
        showTemporary(teachingSaved ? "ÖĞRETME KAYITLI"
                                    : "ÖĞRETME BİTMEDİ");
      } else if (menuIndex == 6) {
        bool depthSaved = calibrateDepthWizard();
        showTemporary(depthSaved ? "DERİNLİK KAYITLI"
                                 : "AYAR DEĞİŞMEDİ");
      } else if (menuIndex == 7) {
        showProfileStatus();
      } else if (menuIndex == 9) {
        runAudioTest();
      } else if (menuIndex == 10) {
        runLiveDiagnostics();
      } else if (menuIndex == 11) {
        runGateScan();
      } else if (menuIndex == 12) {
        bool saved = !settingsDirty || saveSettings();
        if (!saved) showTemporary("HAFIZA HATASI", 1200);
        menuOpen = false;
      }

      if (menuOpen) drawMenu();
    }
    return;
  }

  if (buttonPressed(PIN_BTN_UP)) {
    if (menuIndex == 0 && settings.sensitivity < 10) {
      settings.sensitivity++;
      settingsDirty = true;
    }
    if (menuIndex == 1 && settings.volumeLevel < 10) {
      settings.volumeLevel++;
      settingsDirty = true;
      pt2257Present = applyVolumeLevel();
    }
    if (menuIndex == 2) {
      settings.autoTrack = !settings.autoTrack;
      settingsDirty = true;
      waitButtonRelease(PIN_BTN_UP);
    }
    if (menuIndex == 8 && settings.audioLength < 8) {
      settings.audioLength++;
      settingsDirty = true;
    }
    drawMenu((pt2257Present || menuIndex != 1) ? nullptr : "PT2257 HATASI");
  }

  if (buttonPressed(PIN_BTN_DOWN)) {
    if (menuIndex == 0 && settings.sensitivity > 1) {
      settings.sensitivity--;
      settingsDirty = true;
    }
    if (menuIndex == 1 && settings.volumeLevel > 0) {
      settings.volumeLevel--;
      settingsDirty = true;
      pt2257Present = applyVolumeLevel();
    }
    if (menuIndex == 2) {
      settings.autoTrack = !settings.autoTrack;
      settingsDirty = true;
      waitButtonRelease(PIN_BTN_DOWN);
    }
    if (menuIndex == 8 && settings.audioLength > 1) {
      settings.audioLength--;
      settingsDirty = true;
    }
    drawMenu((pt2257Present || menuIndex != 1) ? nullptr : "PT2257 HATASI");
  }

  if (buttonPressed(PIN_BTN_OK)) {
    waitButtonRelease(PIN_BTN_OK);
    editMode = false;
    bool saved = !settingsDirty || saveSettings();
    drawMenu(saved ? nullptr : "HAFIZA HATASI");
  }
}

// -------------------------------------------------------------------------
// 14. KURULUM
// -------------------------------------------------------------------------
void setup() {
  // Önceki reset watchdog'dan mı geldi? (bayrak okunup temizlenir)
  bool resetByWatchdog = (RCC->CSR & RCC_CSR_IWDGRSTF) != 0;
  RCC->CSR |= RCC_CSR_RMVF;

  pinMode(PIN_TX, OUTPUT);
  pinMode(PIN_BLANK, OUTPUT);
  pinMode(PIN_AUDIO, OUTPUT);
  digitalWrite(PIN_TX, LOW);
  digitalWrite(PIN_BLANK, HIGH);
  audioOff();
  wdtStart();

  pinMode(PIN_BTN_MENU, INPUT_PULLUP);
  pinMode(PIN_BTN_UP, INPUT_PULLUP);
  pinMode(PIN_BTN_DOWN, INPUT_PULLUP);
  pinMode(PIN_BTN_OK, INPUT_PULLUP);

  loadSettings();
  if (!enableCycleCounter()) timingFaultLatched = true;
  adcInitDirect();

  Wire.setSCL(I2C_SCL_PIN);
  Wire.setSDA(I2C_SDA_PIN);
  Wire.begin();
  Wire.setClock(100000);  // PT2257'nin izin verdiği en yüksek I2C hızı

  display.begin();
  display.enableUTF8Print();
  display.setContrast(150);
  showStartupLogo();

  if (resetByWatchdog) {
    drawFourLines("WATCHDOG RESET", "CIHAZ KILITLENDI", "TX KAPATILDI",
                  "BUNU BANA SOYLE");
    safeDelay(2500);
  }

  // Flash kaydından ve TX darbesinden önce besleme ile zamanlama donanımını
  // doğrula. Hata varsa bobin çıkışı LOW durumda kalır.
  batteryVoltage = readBatteryVoltage();
  if (adcFaultLatched || timingFaultLatched) {
    drawHardwareFault();
    return;
  }
  if (!isfinite(batteryVoltage) ||
      batteryVoltage < LOW_BATTERY_CUTOFF_V) {
    lowBatteryLatched = true;
    drawLowBattery();
    return;
  }

  if (settingsDirty) {
    drawFourLines("İLK KURULUM", "HAFIZA HAZIRLIK",
                  "CİHAZI KAPATMA", "BEKLEYİN...");
    if (!saveSettings()) {
      drawFourLines("HAFIZA HATASI", "VARSAYILAN AYAR",
                    "KAYDEDİLEMEDİ", "CİHAZ ÇALIŞACAK");
      safeDelay(1600);
    }
  }

  pt2257Present = initializePt2257();
  if (!pt2257Present) {
    drawFourLines("PT2257 YOK/HATA", "SDA/SCL KONTROL",
                  "BESLEME: 3,3V", "CİHAZ ÇALIŞACAK");
    safeDelay(1800);
  }

  drawFourLines("AKTİF BOBİN", coilName(settings.activeCoil),
                "METALİ UZAK TUT", "AÇILIŞ AYARI");
  safeDelay(500);
  calibrateGround();
  lastMeasurement = measureBlock(false);
}

// -------------------------------------------------------------------------
// 15. ANA ÇALIŞMA DÖNGÜSÜ
// -------------------------------------------------------------------------
void loop() {
  wdtFeed();
  if (timingFaultLatched || adcFaultLatched) {
    drawHardwareFault();
    safeDelay(250);
    return;
  }

  if (millis() - lastBatteryMs >= 1000 || lastBatteryMs == 0) {
    batteryVoltage = readBatteryVoltage();
    lastBatteryMs = millis();
  }

  // Düşük pil bir kez görüldüğünde çalışma bu açılış boyunca kilitli kalır.
  // Böylece yük kalkınca gerilim kısa süre yükselse bile cihaz kalibrasyonsuz
  // veya zayıf pille yeniden darbe üretmez. Kapatıp şarj etmek gerekir.
  if (lowBatteryLatched || batteryVoltage < LOW_BATTERY_CUTOFF_V) {
    lowBatteryLatched = true;
    txLow();
    blankHigh();
    audioOff();
    drawLowBattery();
    safeDelay(250);
    return;
  }

  handleMenu();
  if (menuOpen) {
    safeDelay(10);
    return;
  }

  lastMeasurement = measureBlock(true);
  stabilizeClassification(lastMeasurement);

  if (millis() - lastDisplayMs >= 160) {
    drawMainScreen(lastMeasurement);
    lastDisplayMs = millis();
  }

  playClassTone(lastMeasurement.targetClass);
}
